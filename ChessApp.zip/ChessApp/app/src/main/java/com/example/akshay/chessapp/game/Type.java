package com.example.akshay.chessapp.game;

public enum Type {
    BISHOP, KING, KNIGHT, PAWN, QUEEN, ROOK
}
